#include "Service.h"

ostream& operator<<(ostream& os, const Service& service)
{
    // TODO: insert return statement here
}
